﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditChecklistModule.Models
{
    public class Questions
    {

        public int QuestionNo { get; set; }
        public string Question { get; set; }
    }
}
