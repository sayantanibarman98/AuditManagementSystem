﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Repository
{
    public class LoginRepo : ILoginRepo
    {
        public readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(LoginRepo));
        public async Task<string> GetToken()
        {
            string t = "";
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44396/api/Auth"))
                {
                    string token = await response.Content.ReadAsStringAsync();
                    t = token;
                }
            }
            _log4net.Info("Returning JWT \"" +t+"\" from"+ nameof(LoginRepo));
            return t;
        }
    }
}
