﻿using AuditManagementPortalClientMVC.Models;
using AuditManagementPortalClientMVC.Models.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Repository
{
    public class SeverityRepo : ISeverityRepo
    {
        public readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(SeverityRepo));

        private readonly AuditDbContext _auditDbContext;

        public SeverityRepo(AuditDbContext auditDbContext)
        {
            _auditDbContext = auditDbContext;
        }
        public async Task<AuditResponse> GetResponse(AuditRequest auditRequest)
        { 
            AuditResponse auditResponse = new AuditResponse();
            using (var httpClient = new HttpClient())
            {
                HttpResponseMessage response = await httpClient.PostAsJsonAsync("https://localhost:44398/api/AuditSeverity", auditRequest);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    auditResponse = JsonConvert.DeserializeObject<AuditResponse>(result);
                }
                _log4net.Info("Response " + response + "from " + nameof(SeverityRepo));
            }
            _log4net.Info("Returning response from " + nameof(SeverityRepo));

            return auditResponse;
        }

        public void StoreResponse(StoreAuditResponse auditResponse) 
        {
            _log4net.Info("store Response in DB from " + nameof(SeverityRepo));
            _auditDbContext.storeAuditResponses.Add(auditResponse);
            _auditDbContext.SaveChanges();
        }

    }
}
