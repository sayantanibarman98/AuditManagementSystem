﻿using AuditManagementPortalClientMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Repository
{
    public class UserRepo : IUserRepo
    {
        public List<User> GetUsers()
        {
            List<User> users = new List<User>()
            {
            new User{Username = "Sudipt", Password ="Kumar" },
            new User{Username = "Sayantani", Password ="Barman" },
            new User{Username = "Nisha", Password ="Nisha" },
            new User{Username = "Biswajit", Password ="Nandi" }
            };
            return users;
        }
    }
}
